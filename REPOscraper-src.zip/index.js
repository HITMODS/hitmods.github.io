const fs = require("fs")
const rax = require("retry-axios")
const axios = require("axios")
const {performance} = require("perf_hooks")

args = []

args.push(process.argv[2])
args.push(process.argv[3])
args.push(process.argv[4])

if (!args[0] || !args[1] || !args[2]) {
    console.log("One or more arguments missing.\nUsage: REPOscraper.exe <server version e.g. 8-5> <path to REPO file> <blob signature> <OPTIONAL prefix default=iohm3prodstorage H3>")
    process.exit()
}

var prefix = "iohm3prodstorage"
if (!process.argv[5]) {
    console.log(`Using default URL prefix ${prefix}`)
} else {
    prefix = process.argv[5]
    console.log(`Using user specified URL prefix ${prefix}`)
}

const url = `https://${prefix}.blob.core.windows.net/resources-${args[0]}/`
const blobSig = args[2]

rax.attach()
var counter = 0

if (!fs.existsSync(args[1])) {
    console.log(`File ${args[1]} does not exist/cannot be found.`)
    process.exit()
}

const rawData = fs.readFileSync(args[1])
const repo = JSON.parse(rawData)

function retryFailedRequest(err) {
    if (err.status === 500 && err.config && !err.config.__isRetryRequest) {
        err.config.__isRetryRequest = true;
        return axios(err.config);
    }
    throw err;
}
axios.interceptors.response.use(undefined, retryFailedRequest);

async function downloadImage(imagePath) {
    return new Promise(async (res, rej) => {
        imagePath = imagePath.toLowerCase().replace("\\", "/")

        var folderPath = imagePath.split("/")
        folderPath.pop()
        folderPath = folderPath.join("/")

        if (!fs.existsSync(folderPath)) {
            await fs.mkdirSync(folderPath, { recursive: true })
        }

        if (fs.existsSync(imagePath)) {
            return res()
        }

        await axios({
            url: url + imagePath + blobSig,
            method: "GET",
            responseType: "stream"
        }).then((resp) => {
            const writer = fs.createWriteStream(imagePath)

            resp.data.pipe(writer)

            writer.on("finish", () => {
                console.log(`Downloaded ${imagePath} successfully!`)
                counter += 1
                return res()
            })
    
            writer.on("error", () => {
                if (resp.status == 404) {
                    console.log(`Could not download ${imagePath} - Not found`)
                    return res()
                }
            })
        }).catch((err) => {
            if (err.response.status != 404 && err.response.status != 403) console.log(err)
            console.log(`Could not download ${imagePath} - Error Code ${err.response.status}`)
            return res()
        })
    })
}

(async () => {
    console.log("REPO Scraper - Made with <3 by Anthony Fuller")
    console.log(`There are ${repo.length} entries in the REPO provided.`)
    console.log(`--------------------------------------------------------------------`)
    console.log(`--- Running through the REPO for actor images now.`)

    start = performance.now()
    for (var i in repo) {
        entry = repo[i]
        if (entry.Image) {
            await downloadImage(entry.Image)
        }
    }
    endTime = performance.now() - start

    console.log(`--- Finished running through REPO for actor images.\n--- Found ${counter} unique images in ${endTime}ms.`)
    console.log(`--------------------------------------------------------------------`)
    console.log(`--- Running through and creating outfit image paths.`)

    counter = 0
    start = performance.now()
    for (var i in repo) {
        entry = repo[i]
        if (entry.Outfit && entry.Outfit != "00000000-0000-0000-0000-000000000000") {
            imagePath = `images/actors/actor_${entry.Outfit}_${(entry.OutfitVariationIndex ? Math.floor(entry.OutfitVariationIndex) : "0")}_${(entry.CharacterSetIndex ? Math.floor(entry.CharacterSetIndex) : "0")}_0.jpg`
            await downloadImage(imagePath)
        }
    }
    endTime = performance.now() - start
    console.log(`--- Finished creating outfit image paths.\n--- Found ${counter} unique images in ${endTime}ms.`)

    console.log("Thanks for using.")
})()
